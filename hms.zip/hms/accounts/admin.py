from django.contrib import admin
from .models import Carousel, CompanyName, ContactUs, AboutText

admin.site.register(Carousel)
admin.site.register(CompanyName)
admin.site.register(ContactUs)
admin.site.register(AboutText)
