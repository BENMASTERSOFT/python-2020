from django.shortcuts import render
from departments.models import Departments, Hod, DeptServices
from accounts.models import Carousel, ContactUs, AboutText, AboutUs
from keyfeatures.models import Keyfeatures
from chiefmedical.models import ChiefMedical
from schools.models import Schools
from team.models import Team
from doctors.models import Specialization


def home(request):
    departments = Departments.objects.all()
    features = Keyfeatures.objects.all()
    chiefmedical = ChiefMedical.objects.all()
    team_members = Team.objects.all()
    contactus = ContactUs.objects.all()
    schoollist = Schools.objects.all()
    specializations = Specialization.objects.all()
    navbar = {"contactus": contactus,
              "specializations": specializations, 'schoollist': schoollist}
    dep_arr = []

    temp = []
    for index, d in enumerate(departments):
        temp.append(d)
        if (index+1) % 4 == 0:
            dep_arr.append(temp)
            temp = []
        if index == (len(departments)-1):
            dep_arr.append(temp)

    sch_arr = []

    temp = []
    for index, d in enumerate(schoollist):
        temp.append(d)
        if (index+1) % 2 == 0:
            sch_arr.append(temp)
            temp = []
        elif index == (len(schoollist)-1):
            sch_arr.append(temp)

    carousel_items = Carousel.objects.all()
    context = {'departments': departments,
               'departments_array': dep_arr,
               'schools_array': sch_arr,
               'keyfeatures': features,
               'carousel_items': carousel_items,
               'chiefmedical': chiefmedical,
               'team_members': team_members,
               'contactus': contactus,
               'navbar': navbar,
               'aboutus': 'About us'}

    return render(request, 'accounts/dashboard.html', context)


def about_us(request):
    team_members = Team.objects.all()
    contactus = ContactUs.objects.all()
    aboutus = AboutText.objects.all()
    chiefmedical = ChiefMedical.objects.all()
    schoollist = Schools.objects.all()
    specializations = Specialization.objects.all()
    navbar = {"contactus": contactus,
              "specializations": specializations, 'schoollist': schoollist}

    context = {'contactus': contactus,
               'navbar': navbar,
               'aboutus': aboutus,
               'chiefmedical': chiefmedical,
               'team_members': team_members}

    return render(request, 'accounts/aboutus.html', context)


def contact_us(request):
    contactus = ContactUs.objects.all()
    aboutus = AboutUs.objects.all()
    schoollist = Schools.objects.all()
    specializations = Specialization.objects.all()
    navbar = {"contactus": contactus,
              "specializations": specializations, 'schoollist': schoollist}
    context = {'contactus': contactus,
               'navbar': navbar,
               'aboutus': aboutus,
               'contactus':  contactus,
               }
    return render(request, 'accounts/contactus.html', context)
