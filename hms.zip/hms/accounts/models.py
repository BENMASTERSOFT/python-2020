from django.db import models
from ckeditor.fields import RichTextField


class CompanyName(models.Model):
    text = models.CharField(max_length=20)
    details = models.CharField(max_length=200, default='', blank=True)

    def __str__(self):
        return self.text


class Carousel(models.Model):
    title = models.CharField(max_length=50)
    body = models.CharField(max_length=120)
    image = models.ImageField(null=True, blank=True, upload_to="carousel/")

    def __str__(self):
        return self.title


class ContactUs(models.Model):
    companyname = models.ForeignKey(CompanyName, on_delete=models.CASCADE)
    address = models.CharField(max_length=120)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=50)
    email = models.CharField(max_length=120)
    phone = models.CharField(max_length=100)
    website = models.CharField(max_length=50)
    twitter = models.CharField(max_length=50,  default='', blank=True)
    facebook = models.CharField(max_length=50,  default='', blank=True)
    instagram = models.CharField(max_length=50,  default='', blank=True)
    linkedin = models.CharField(max_length=50,  default='', blank=True)
    googleplus = models.CharField(max_length=50,  default='', blank=True)
    youtube = models.CharField(max_length=50,  default='', blank=True)

    def __str__(self):
        return self.address


class AboutUs(models.Model):
    companyname = models.ForeignKey(CompanyName, on_delete=models.CASCADE)
    image = models.ImageField(null=True, blank=True, upload_to="about/")


class AboutText(AboutUs):
    text = RichTextField(blank=True, null=True)

    def __str__(self):
        return self.text
