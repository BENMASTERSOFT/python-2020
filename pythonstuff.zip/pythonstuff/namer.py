#####################################
# Learn Python Coding in 2020
# By Ben Mastersoft
# mastersoft.com.ng
###################################

def nameit(name):
	print("Hello there " + name)
