#####################################
# Learn Python Coding in 2020
# By Ben Mastersoft
# mastersoft.com.ng
###################################
import os
from namer import nameit

os.system("clear")

nameit("Ben")