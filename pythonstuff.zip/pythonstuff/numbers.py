import os
os.system('clear')

name = "Ben Mastersoft"
############################################
# Data Types
# Strings
# Numbers
# Lists
# Tuple
# Dictionaries
# Boolean
##########################################


num = 10
num1 = 10.25
print(num)
print(float(num))
print(int(num1))

#Maths
print("7+2 is " + str(7+2))
print("7-2 is " + str(7-2))
print("7*+2 is " + str(7*2))
print("7/2 is " + str(7/2))
print("7%2 is " + str(7%2))
print("5**2 is " + str(5**2))
print("5**3 is " + str(5**3))