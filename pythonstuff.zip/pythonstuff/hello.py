import os
os.system('clear')

print("Hello world")

first_name = 'Ben'
name = ['John', 'Bob', "Mary"]


fav_pizza = {
	"John": "Pepperoni",
	"Bob": "Mushroom",
	"Mary": "Cheese"
}

print(name[0])

print(fav_pizza["Bob"])
